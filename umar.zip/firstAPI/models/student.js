import mongoose from "mongoose";

const studentSchema = new mongoose.Schema(
    {
        firstName : {
            type : String,
            required : true,
            trim : true,
            maxlength : 32
        },
        lastname : {
            type : true,
            maxlength : 32,
        },
        course : {
            type : String,
            required : true,
            trim : true
        },
        fatherName : {
            type : String,
            required : true,
            maxlength : 32,
            trim : true
        },
        address : {
            type : String,
            required : true,
            trim : true
        }
    },
    {
        timestamps : true
    }
);

module.exports = mongoose.model("Student", studentSchema);