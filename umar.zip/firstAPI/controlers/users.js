
import { v4 as uuidv4 } from 'uuid';

let users = [];  //Empty users array 

export const getUser =  (req, res) => {
    res.send(users);
}

export const createUser =  (req, res) => {
    const user = req.body;

    const userID = uuidv4();

    const userWithId = { ...user , RollNo : userID};

    users.push(userWithId);

    res.send(`User with name ${user.firstName} added to the database`);
}

export const getUserWithId =  (req,res) => {
    const { id } = req.params;

    const foundUser = users.find((user) => user.RollNo == id);
    res.send(foundUser);
}

export const deleteUser = (req, res) => {
    const { id } = req.params;

    users = users.filter((user) => user.RollNo != id);
    res.send(`User with ${id} deleted successfuly from database`);
}

export const updateUser = (req, res) => {
    const { id } = req.params;

    const {firstName, lastName, course, fathername , address } = req.body;

    const user = users.find((user) => user.RollNo == id);

    if(firstName){
        user.firstName = firstName;
    }
    if(lastName){
        user.lastName = lastName;
    }
    if(course){
        user.course = course;
    }
    if(fathername){
        user.fathername = fathername;
    }
    if(address){
        user.address = address;
    }

    res.send(`User with the ${user.firstName} has been updated succesfully`);
}

// export const getUserAddress = (req, res) => {
//     let address = [];

//     for(let i = 0; i < users.length;i++)
//     {
//         console.log(users[i]);
//     }
//     res.send(address);
// }

export const getUserAddressWithId = (req, res) => {
    const { id } = req.params;

    const foundUser = users.find((user) => user.RollNo == id);

    res.send(foundUser.address);
}